# Group Contributions

All group members have completed their assigned tasks and reviewed their allocated sections. Each member is responsible for checking their own work and the sections assigned for review. All members agree with the contributions recorded below.

| Member | Role | Owns | Reviews | Main issue found/fixed |
|---|---|---|---|---|
| Muhammad Haris bin Abdul Halim (313778) | 1 — Data steward | Tasks 1 and 3, data downloads, requirements.txt and README setup section | Task 2 | Checked dataset validation and confirmed that the required data files were available. |
|  Muhammad Irsyad bin Ahmad Zubaini (312594) | 2 — Structures engineer | Task 2, matrix shapes and row/column order | Tasks 1 and 3 | Checked the data structure, matrix dimensions and order of states and years. |
| Aqil As-Syakirin bin Zulkefli (312950) | 3 — Matrix analyst A | Tasks 4.1–4.5 and relative income index | Tasks 4.6–4.7 and Task 5.1 | Checked the income calculations and relative income index results. |
| Keshvinraj A/L Sureish (312509) | 4 — Matrix analyst B | Tasks 4.6–4.7 and Task 5.1 | Tasks 4.1–4.5 | Checked the state profiles, income and poverty results, and profile data. |
| Muhammad Izzul Iman bin Mohd Jamaluddin (311280) | 5 — Integration and test lead | Tasks 5.2 and 5.4, Task 5.3 table, notebook and README assembly | Every function | Ran the notebook from a restarted kernel and confirmed that all check cells passed. Checked the final file structure. |