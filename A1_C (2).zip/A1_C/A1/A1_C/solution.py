"""Shared functions for DOSM household income and poverty assignment."""
import json
import re
import numpy as np

SURVEY_YEARS = [2016, 2019, 2020, 2022, 2024]
POVERTY_YEARS = [2019, 2020, 2022, 2024]
REGIONS = {
    "Northern": ["Perlis", "Kedah", "Pulau Pinang", "Perak"],
    "Central": ["Selangor", "W.P. Kuala Lumpur", "W.P. Putrajaya", "Negeri Sembilan"],
    "Southern": ["Melaka", "Johor"],
    "East Coast": ["Kelantan", "Terengganu", "Pahang"],
    "East Malaysia": ["Sabah", "Sarawak", "W.P. Labuan"],
}


def get_year(record):
    """Get the year from a record's date.

    Owner: Muhammad Irsyad (Role 2). Reviewed by: Muhammad Haris (Role 1).
    """
    return int(str(record["date"])[:4])


def validate_records(records: list[dict], required_keys: tuple[str, ...]) -> None:
    """Validate a list of records and unique (state, date) pairs.

    Owner: Muhammad Haris (Role 1). Reviewed by: Muhammad Irsyad (Role 2).
    """
    if not isinstance(records, list):
        raise TypeError("records must be a list")
    if not records:
        raise ValueError("records must not be empty")
    seen = set()
    for i, record in enumerate(records):
        if not isinstance(record, dict):
            raise TypeError(f"record at index {i} must be a dictionary")
        missing = [key for key in required_keys if key not in record]
        if missing:
            raise ValueError(f"record at index {i} is missing required keys: {missing}")
        if "state" in record and "date" in record:
            key = (record["state"], record["date"])
            if key in seen:
                raise ValueError(f"duplicate (state, date) record: {key}")
            seen.add(key)


def index_by_key(records):
    """Index records by (state, year), rejecting duplicate keys.

    Owner: Muhammad Irsyad (Role 2). Reviewed by: Muhammad Haris (Role 1).
    """
    result = {}
    for record in records:
        key = (record["state"], get_year(record))
        if key in result:
            raise ValueError(f"duplicate (state, year) key: {key}")
        result[key] = record
    return result


def join_records(income_records, poverty_records):
    """Join datasets by state and year and return unmatched keys.

    Owner: Muhammad Irsyad (Role 2). Reviewed by: Muhammad Haris (Role 1).
    """
    income = index_by_key(income_records)
    poverty = index_by_key(poverty_records)
    common = income.keys() & poverty.keys()
    joined = []
    for key in sorted(common, key=lambda item: (item[1], item[0])):
        row = dict(income[key])
        for field, value in poverty[key].items():
            if field not in ("state", "date"):
                row[field] = value
        joined.append(row)
    return joined, sorted(income.keys() - poverty.keys()), sorted(poverty.keys() - income.keys())


def to_float(value):
    """Convert a numeric value to float and None to np.nan.

    Owner: Muhammad Irsyad (Role 2). Reviewed by: Muhammad Haris (Role 1).
    """
    return np.nan if value is None else float(value)


def focus_states(matric_numbers, states):
    """Assign distinct focus states in ascending matric-number order.

    Owner: Muhammad Haris (Role 1). Reviewed by: Muhammad Irsyad (Role 2).
    """
    if len(states) != 16 or len(set(states)) != 16:
        raise ValueError("states must contain exactly 16 distinct state names")
    if len(matric_numbers) > len(states):
        raise ValueError("there cannot be more group members than available states")
    digits = []
    for matric in matric_numbers:
        found = re.sub(r"\D", "", str(matric))
        if not found:
            raise ValueError(f"matric number has no digits: {matric}")
        digits.append((int(found), matric))
    if len({number for number, _ in digits}) != len(digits):
        raise ValueError("matric numbers must be unique")
    assigned = []
    used = set()
    for number, _ in sorted(digits):
        position = number % 16
        for offset in range(16):
            candidate = states[(position + offset) % 16]
            if candidate not in used:
                assigned.append((number, candidate))
                used.add(candidate)
                break
    by_number = {number: state for number, state in assigned}
    return [by_number[number] for number, _ in sorted(digits)]


def state_region_map(states, regions):
    """Map each state to exactly one region.

    Owner: Keshvinraj (Role 4). Reviewed by: Aqil As-Syakirin (Role 3).
    """
    mapping = {}
    for region, members in regions.items():
        for state in members:
            if state in mapping:
                raise ValueError(f"state belongs to more than one region: {state}")
            mapping[state] = region
    missing = set(states) - set(mapping)
    extra = set(mapping) - set(states)
    if missing or extra:
        raise ValueError(f"region membership mismatch; missing={sorted(missing)}, extra={sorted(extra)}")
    if len(mapping) != len(states):
        raise ValueError("every state must belong to exactly one region")
    return mapping


def build_state_profile(state: str, states: list[str], years: list[int], median: np.ndarray,
                        mean: np.ndarray, poverty: np.ndarray, poverty_years: list[int],
                        regions: dict[str, list[str]]) -> dict:
    """Return a JSON-serializable profile for one state.

    Owner: Keshvinraj (Role 4). Reviewed by: Aqil As-Syakirin (Role 3).
    """
    if state not in states:
        raise ValueError(f"unknown state: {state}")
    region_map = state_region_map(states, regions)
    row = states.index(state)
    latest_col = len(years) - 1
    country_median = float(np.median(median[:, latest_col]))
    indices = median[:, latest_col] / country_median
    rank = int(np.sum(median[:, latest_col] > median[row, latest_col]) + 1)
    region_rows = [i for i, name in enumerate(states) if region_map[name] == region_map[state]]
    region_mean = float(np.mean(median[region_rows, latest_col]))
    growth = float((median[row, -1] - median[row, 0]) / median[row, 0] * 100)
    poverty_values = []
    for i, year in enumerate(poverty_years):
        value = float(poverty[row, i])
        poverty_values.append({"year": int(year), "absolute_poverty": None if np.isnan(value) else value})
    flagged = []
    # Period flags correspond to Task 4.7 and are derived from consecutive poverty years.
    for y1, y2 in zip(poverty_years[:-1], poverty_years[1:]):
        if y1 in years and y2 in years:
            a, b = years.index(y1), years.index(y2)
            p1, p2 = poverty_years.index(y1), poverty_years.index(y2)
            poverty_pair = poverty[row, [p1, p2]]
            if (median[row, b] > median[row, a]
                    and not np.any(np.isnan(poverty_pair))
                    and poverty[row, p2] >= poverty[row, p1]):
                flagged.append(f"{y1}-{y2}")
    return {
        "state": state,
        "region": region_map[state],
        "income": [{"year": int(years[i]), "median": float(median[row, i]), "mean": float(mean[row, i])} for i in range(len(years))],
        "growth_2016_2024_percent": growth,
        "relative_income_index_latest": float(indices[row]),
        "relative_income_rank_latest": rank,
        "region_mean_median_latest": region_mean,
        "above_region_mean_latest": bool(median[row, latest_col] > region_mean),
        "absolute_poverty": poverty_values,
        "flagged_periods": flagged,
    }


def relative_income_index(median):
    """Calculate each state's median relative to the cross-state median by year.

    Owner: Aqil As-Syakirin (Role 3). Reviewed by: Keshvinraj (Role 4).
    """
    return median / np.median(median, axis=0, keepdims=True)