# DOSM Household Income and Poverty Audit

**Group C**

## Members and Focus States

The focus states were assigned using the matric number rule and checked against the notebook results.

| Name | Matric Number | Role | Focus State |
|---|---:|---|---|
| Muhammad Haris bin Abdul Halim | 313778 | 1 - Data steward | Melaka |
| Muhammad Irsyad bin Ahmad Zubaini | 312594 | 2 - Structures engineer | Kelantan |
| Aqil As-Syakirin bin Zulkefli | 312950 | 3 - Matrix analyst A | Perak |
| Keshvinraj A/L Sureish | 312509 | 4 - Matrix analyst B | W.P. Kuala Lumpur |
| Muhammad Izzul Iman bin Mohd Jamaluddin | 311280 | 5 - Integration and test lead | Johor |

## Setup and Running Instructions

1. Install Python 3.11 or newer.
2. Install the required package by running:

   ```bash
   py -m pip install -r requirements.txt
   ```

3. Ensure both JSON datasets are available in the `data/raw/` folder.
4. Open `assignment1.ipynb` in VS Code and select the Python kernel.
5. Select **Kernel → Restart Kernel and Run All Cells** to run the complete notebook.
6. Check that all tests and assertions pass.

## Dataset Information

The datasets used in this assignment are from the Department of Statistics Malaysia (DOSM).

- `hh_income_state.json` — Household income data by state.
- `hh_poverty_state.json` — Poverty data by state.

**Data download date:** 27 October 2026. The exact retrieval timestamp is recorded in the JSON metadata where available.

**LMS fallback used:** No, if the files were downloaded directly using the official data download script.

## Completion Checklist

- [x] Both raw JSON datasets are available.
- [x] Focus states are checked against the notebook output.
- [x] The notebook runs from a fresh kernel.
- [x] All notebook checks and assertions pass.
- [x] Tasks 1–5 have been run.
- [x] Group contributions are documented.
- [x] Results and interpretations are prepared for final review.

## References

1. Department of Statistics Malaysia. *Household Income by State*. OpenDOSM. https://open.dosm.gov.my/data-catalogue/hh_income_state
2. Department of Statistics Malaysia. *Household Income and Expenditure: States*. OpenDOSM. https://open.dosm.gov.my/data-catalogue/hies_state
3. Department of Statistics Malaysia. *Monthly Household Gross Income by State, 2024*. https://storage.dosm.gov.my/hies/household_income_2024.pdf
4. NumPy Developers. *NumPy Documentation: User Guide*. https://numpy.org/doc/stable/user/